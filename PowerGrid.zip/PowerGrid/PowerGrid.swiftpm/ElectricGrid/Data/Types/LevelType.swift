import Foundation

public enum LevelType: String {
    case high = "High"
    case medium = "Medium"
    case low = "Low"
}
